var suma = 0, number = 99;
parseInt(number);
while(number != 0){
    number= prompt("UN NUMERO!")*1;
    suma += number;
}

alert(suma);