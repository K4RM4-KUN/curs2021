var intro = prompt("Di algo!"),palabras = intro.split(" ");
alert("Texto: "+intro+".\nCaracteres: "+intro.length+"\nPalabras: "+palabras.length+"\nTexto mayusculas: "+intro.toUpperCase()+"");