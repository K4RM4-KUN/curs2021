var edad = prompt("Dime tu edad!")*1;

if (edad != 18){
    alert("Voste no te 18 anys!");
} else {
    alert("Voste te 18 anys!");
}

//Operador ternari
//var edad = prompt("Dime tu edad!")*1;

//if ((!edad = 18)){
//    alert("Voste no te 18 anys!");
//} else {
//    alert("Voste te 18 anys!");
//}