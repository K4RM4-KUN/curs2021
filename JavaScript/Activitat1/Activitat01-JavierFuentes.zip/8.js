var sumatotal = 0,addnum = 0;

while (!(sumatotal >= 100)){
    addnum = prompt("UN NUMERO!")*1;
    sumatotal += addnum;
};
alert("Has llegado a 100 o más!")