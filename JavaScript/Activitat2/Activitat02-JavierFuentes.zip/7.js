var intro = prompt("Dime un numero decimal:");

intro = (Math.round(intro * 100))/100;

alert(intro);