if (confirm ("Apreta uno de los botones!")){
    alert("Aceptar");
} else {
    alert("Cancelar");
}