var activites = $("#schedule");
var buttonA = $(".add");
var buttonX = $(".X");
var dateT = $(".dateV");
var nameT =  $(".nameV");

buttonA.click(function(){
    let add = "<table class='activites'><tr><td class='date'><text>"+$(dateT).val()+"</text></td><td class='name'><text>"+$(nameT).val()+"</text></td><td class='X'>X</td></tr></table>";
    $(add).prependTo($("#schedule"));
});

$("#schedule").on("click",'.X' ,function() {
  var parent = $(this).parent().parent().parent().remove();
});