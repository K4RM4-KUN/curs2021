var d = new Date();
alert("Dia de la semana: "+d.getDate()+"\nMes del año: "+d.getMonth()+"\nAño: "+d.getFullYear()+"\nHora: "+d.getHours()+"\nMinutos: "+d.getMinutes()+"\nSegundos: "+d.getSeconds());