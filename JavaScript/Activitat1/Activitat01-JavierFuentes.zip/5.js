var suma = 0;
for(let i=0; i<5; i++) {
   var tmp = prompt("Diguem un numero")*1;
   suma += tmp;
}

alert(suma);