var pass = "";
while(pass != "password" && pass != "clauAcces" && pass != "secretKey"){
    pass = prompt("Cual es la contrasenya:");
}

alert("CORRECTE");